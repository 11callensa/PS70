import asyncio
from bleak import BleakScanner, BleakClient
import socket

SERVICE_UUID = "12345678-1234-1234-1234-1234567890ab"
CHARACTERISTIC_UUID = "87654321-4321-4321-4321-ba0987654321"

UDP_IP = "127.0.0.1"
UDP_PORT = 5005

udp_socket = socket.socket(
    socket.AF_INET,
    socket.SOCK_DGRAM
)

stylus_state = {
    "w": 1.0,
    "x": 0.0,
    "y": 0.0,
    "z": 0.0,

    "wheel": 0,
    "wheel_click": False,
    "mode_button": False
}


async def notification_handler(sender, data):
    try:
        message = data.decode()

        parts = message.split(";")

        quaternion = (parts[0].replace("Q:", "").split(","))

        stylus_state["w"] = float(quaternion[0])
        stylus_state["x"] = float(quaternion[1])
        stylus_state["y"] = float(quaternion[2])
        stylus_state["z"] = float(quaternion[3])

        stylus_state["wheel"] = int(parts[1].replace("W:", ""))
        stylus_state["wheel_click"] = bool(int(parts[2].replace("WC:", "")))
        stylus_state["mode_button"] = bool(int(parts[3].replace("MB:", "")))

        packet = (
            "STATE;"
            f"{stylus_state['w']},"
            f"{stylus_state['x']},"
            f"{stylus_state['y']},"
            f"{stylus_state['z']};"
            f"{stylus_state['wheel']};"
            f"{int(stylus_state['wheel_click'])};"
            f"{int(stylus_state['mode_button'])}"
        )

        udp_socket.sendto(
            packet.encode(),
            (UDP_IP, UDP_PORT)
        )

        # print("----------------")
        print(
            "Quaternion:",
            stylus_state["w"],
            stylus_state["x"],
            stylus_state["y"],
            stylus_state["z"]
        )

        # print("Wheel:", stylus_state["wheel"])
        # print("Wheel click:", stylus_state["wheel_click"])
        # print("Mode:", stylus_state["mode_button"])

    except Exception as e:
        print("Packet error:")
        print(data)
        print(e)


def disconnected(client):
    print("Stylus disconnected")

    udp_socket.sendto(
        b"DISCONNECTED",
        (UDP_IP, UDP_PORT)
    )


async def main():
    print("Scanning...")

    devices = await BleakScanner.discover()
    target = None

    for device in devices:

        print(device.name, device.address)

        if device.name == "SpatialStylus":
            target = device

    if target is None:
        print("Couldn't find stylus.")
        return

    print("Connecting...")

    async with BleakClient(target.address, disconnected_callback=disconnected) as client:
        print("Connected!")

        udp_socket.sendto(
            b"CONNECTED",
            (UDP_IP, UDP_PORT)
        )

        await client.start_notify(CHARACTERISTIC_UUID, notification_handler)

        print("Receiving data...")

        while True:
            await asyncio.sleep(1)

asyncio.run(main())