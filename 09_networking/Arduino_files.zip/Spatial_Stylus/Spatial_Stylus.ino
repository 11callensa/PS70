#include "BLEManager.h"
#include "Button.h"
#include "RotaryEncoder.h"
#include "IMUManager.h"
#include "StylusState.h"


BLEManager ble;


// Rotary encoder
// CLK = D0
// DT  = D1
// SW  = D2
RotaryEncoder encoder(D0, D1, D2);

// Mode button
// Button between D6 and GND
Button modeButton(
    D6
);

// IMU
IMUManager imuManager;

// Current stylus state
StylusState state;

// Timer for BLE sending
unsigned long lastSend = 0;

void setup()
{
    Serial.begin(115200);
    Serial.println("Starting Spatial Stylus...");

    ble.begin();
    encoder.begin();
    modeButton.begin();
    imuManager.begin();

    Serial.println("Waiting for Bluetooth connection...");
}

void loop()
{
    encoder.update();
    modeButton.update();
    imuManager.update();


    // Read encoder rotation
    int rotation = encoder.getRotation();


    // Accumulate wheel movement
    if(rotation != 0)
    {
        state.wheelDelta += rotation;
    }


    // Store button events
    if(encoder.wasClicked())
    {
        state.wheelPressed = true;
    }


    if(modeButton.wasPressed())
    {
        state.modePressed = true;
    }


    // Update continuous values
    state.orientation = imuManager.getOrientation();

    state.batteryVoltage = 0;

    // Debug
    if(rotation != 0)
    {
        Serial.print("ROTATION: ");
        Serial.println(rotation);
    }


    if(state.wheelPressed)
    {
        Serial.println("WHEEL CLICK");
    }


    if(state.modePressed)
    {
        Serial.println("MODE BUTTON");
    }

    // BLE
    if(millis() - lastSend > 10)
    {
        lastSend = millis();


        String message =
            "Q:" +
            String(state.orientation.w) + "," +
            String(state.orientation.x) + "," +
            String(state.orientation.y) + "," +
            String(state.orientation.z)

            +

            ";W:" +
            String(state.wheelDelta)

            +

            ";WC:" +
            String(state.wheelPressed)

            +

            ";MB:" +
            String(state.modePressed);


        Serial.println(message);

        ble.send(message);


        // Clear one-shot events
        state.wheelDelta = 0;
        state.wheelPressed = false;
        state.modePressed = false;
    }
}