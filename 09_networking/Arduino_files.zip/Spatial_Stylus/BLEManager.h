#ifndef BLEMANAGER_H
#define BLEMANAGER_H

#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define SERVICE_UUID        "12345678-1234-1234-1234-1234567890ab"
#define CHARACTERISTIC_UUID "87654321-4321-4321-4321-ba0987654321"

class BLEManager
{
private:

    BLECharacteristic* characteristic;
    bool connected;

    class ServerCallbacks : public BLEServerCallbacks
    {
    private:
        BLEManager* parent;

    public:
        ServerCallbacks(BLEManager* bleManager);

        void onConnect(BLEServer* server) override;

        void onDisconnect(BLEServer* server) override;
    };

public:

    BLEManager();

    void begin();

    void send(String message);

    bool isConnected();
};

#endif