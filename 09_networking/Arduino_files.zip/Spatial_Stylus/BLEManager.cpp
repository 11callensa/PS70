#include "BLEManager.h"

BLEManager::BLEManager()
{
    connected = false;
    characteristic = nullptr;
}

BLEManager::ServerCallbacks::ServerCallbacks(BLEManager* bleManager)
{
    parent = bleManager;
}


void BLEManager::ServerCallbacks::onConnect(BLEServer* server)
{
    parent->connected = true;

    Serial.println("BLE Connected");
}


void BLEManager::ServerCallbacks::onDisconnect(BLEServer* server)
{
    parent->connected = false;

    Serial.println("BLE Disconnected");

    BLEDevice::startAdvertising();
}


void BLEManager::begin()
{
    BLEDevice::init("SpatialStylus");

    BLEServer* server = BLEDevice::createServer();

    server->setCallbacks(
        new ServerCallbacks(this)
    );

    BLEService* service =
        server->createService(
            SERVICE_UUID
        );

    characteristic =
        service->createCharacteristic(
            CHARACTERISTIC_UUID,
            BLECharacteristic::PROPERTY_NOTIFY |
            BLECharacteristic::PROPERTY_READ
        );

    characteristic->addDescriptor(
        new BLE2902()
    );

    service->start();

    BLEAdvertising* advertising =
        BLEDevice::getAdvertising();

    advertising->start();

    Serial.println("BLE Advertising...");
}


void BLEManager::send(String message)
{
    if(!connected)
        return;

    characteristic->setValue(
        message.c_str()
    );

    characteristic->notify();

    Serial.println(message);
}


bool BLEManager::isConnected()
{
    return connected;
}