#include "Button.h"
#include <Arduino.h>


Button::Button(int buttonPin)
{
    pin = buttonPin;

    lastReading = HIGH;
    buttonState = HIGH;

    pressedFlag = false;

    lastDebounceTime = 0;

    debounceDelay = 50;
}


void Button::begin()
{
    pinMode(
        pin,
        INPUT_PULLUP
    );

    lastReading = digitalRead(pin);
    buttonState = lastReading;
}


void Button::update()
{
    bool currentReading = digitalRead(pin);


    if(currentReading != lastReading)
    {
        lastDebounceTime = millis();
    }


    if(
        (millis() - lastDebounceTime)
        > debounceDelay
    )
    {

        if(currentReading != buttonState)
        {
            buttonState = currentReading;


            if(buttonState == LOW)
            {
                pressedFlag = true;
            }
        }

    }


    lastReading = currentReading;
}


bool Button::wasPressed()
{
    if(pressedFlag)
    {
        pressedFlag = false;

        return true;
    }

    return false;
}