#ifndef QUATERNION_H
#define QUATERNION_H

// Quaternion.h
struct Quaternion
{
    float w;
    float x;
    float y;
    float z;
};

#endif